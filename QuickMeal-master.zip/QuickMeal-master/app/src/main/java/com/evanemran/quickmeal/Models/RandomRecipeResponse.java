package com.evanemran.quickmeal.Models;

import java.util.List;

public class RandomRecipeResponse {
    List<RandomRecipe> recipes;

    public List<RandomRecipe> getRecipes() {
        return recipes;
    }
}
