package com.evanemran.quickmeal.Models;

public class Metric {
    public double amount;
    public String unitShort;
    public String unitLong;

    public double getAmount() {
        return amount;
    }

    public String getUnitShort() {
        return unitShort;
    }

    public String getUnitLong() {
        return unitLong;
    }
}
