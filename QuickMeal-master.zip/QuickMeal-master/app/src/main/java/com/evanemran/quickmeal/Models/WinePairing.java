package com.evanemran.quickmeal.Models;

import java.util.List;

public class WinePairing {
    public List<String> pairedWines;
    public String pairingText;
    public List<ProductMatch> productMatches;
}
