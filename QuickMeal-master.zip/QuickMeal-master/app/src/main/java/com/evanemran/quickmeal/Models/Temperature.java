package com.evanemran.quickmeal.Models;

public class Temperature {
    public int number;
    public String unit;

    public int getNumber() {
        return number;
    }

    public String getUnit() {
        return unit;
    }
}
