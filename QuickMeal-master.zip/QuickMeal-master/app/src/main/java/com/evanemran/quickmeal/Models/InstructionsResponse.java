package com.evanemran.quickmeal.Models;

import java.util.List;

public class InstructionsResponse {
    public String name;
    public List<Step> steps;
}
