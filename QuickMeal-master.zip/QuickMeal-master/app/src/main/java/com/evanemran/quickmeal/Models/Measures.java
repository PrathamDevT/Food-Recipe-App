package com.evanemran.quickmeal.Models;

public class Measures {
    public Us us;
    public Metric metric;

    public Us getUs() {
        return us;
    }

    public Metric getMetric() {
        return metric;
    }
}
