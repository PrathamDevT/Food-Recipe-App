package com.evanemran.quickmeal.Listeners;

public interface CustomOnClickListener {
    void onClick(String text);
}
