package com.evanemran.quickmeal.Models;

public class Length {
    public int number;
    public String unit;

    public int getNumber() {
        return number;
    }

    public String getUnit() {
        return unit;
    }
}
